<?php
/**
 * RCS ESS API - Configuration & Helper Functions
 * Shared across all ESS endpoints
 */

// CORS Headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-API-KEY');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ============================================================================
// Database Connection
// ============================================================================

function getDbConnection() {
    static $conn = null;
    if ($conn !== null && $conn->ping()) {
        return $conn;
    }

    // Adjust these to match your server
    $host     = 'localhost';
    $username = 'rcsfaxhz_bolt';
    $password = 'rcsfaxhz_bolt';
    $dbname   = 'rcsfaxhz_bolt';

    // Try common cPanel paths for DB credentials
    $credFiles = [
        '/home/rcsfaxhz/domains/join.rcsfacility.com/public_html/api/ess/db_credentials.php',
        '/home/rcsfaxhz/domains/join.rcsfacility.com/public_html/api/ess/config.php',
        __DIR__ . '/db_credentials.php',
    ];

    foreach ($credFiles as $file) {
        if (file_exists($file) && $file !== __FILE__) {
            // Extract DB config from existing config (without loading helpers)
            $content = file_get_contents($file);
            if (preg_match("/\\\$host\s*=\s*['\"]([^'\"]+)['\"]/i", $content, $m)) $host = $m[1];
            if (preg_match("/\\\$username\s*=\s*['\"]([^'\"]+)['\"]/i", $content, $m)) $username = $m[1];
            if (preg_match("/\\\$password\s*=\s*['\"]([^'\"]*)['\"]/i", $content, $m)) $password = $m[1];
            if (preg_match("/\\\$dbname\s*=\s*['\"]([^'\"]+)['\"]/i", $content, $m)) $dbname = $m[1];
            break;
        }
    }

    $conn = new mysqli($host, $username, $password, $dbname);

    if ($conn->connect_error) {
        jsonError('Database connection failed: ' . $conn->connect_error, 500);
    }

    $conn->set_charset('utf8mb4');
    return $conn;
}

// ============================================================================
// Response Helpers
// ============================================================================

function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function jsonSuccess($data = null, $message = null) {
    $response = ['success' => true];
    if ($message !== null) $response['message'] = $message;
    if ($data !== null) $response['data'] = $data;
    jsonResponse($response);
}

function jsonError($error, $statusCode = 400) {
    jsonResponse(['success' => false, 'error' => $error], $statusCode);
}

// ============================================================================
// Input Helpers
// ============================================================================

function getQueryParam($name, $default = null) {
    return isset($_GET[$name]) ? $_GET[$name] : $default;
}

function getJsonInput() {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    if ($data === null) {
        jsonError('Invalid JSON input. Please send valid JSON.', 400);
    }
    return $data;
}

function getRequiredParam($data, $key) {
    if (!isset($data[$key]) || $data[$key] === '') {
        jsonError("Missing required field: {$key}", 400);
    }
    return $data[$key];
}

// ============================================================================
// Pagination Helper
// ============================================================================

function getPaginationParams() {
    $page  = max(1, intval(getQueryParam('page', 1)));
    $limit = min(100, max(1, intval(getQueryParam('limit', 20))));
    $offset = ($page - 1) * $limit;
    return ['page' => $page, 'limit' => $limit, 'offset' => $offset];
}

function buildPaginationResponse($total, $page, $limit, $items) {
    $totalPages = max(1, ceil($total / $limit));
    return [
        'items' => $items,
        'pagination' => [
            'page'        => $page,
            'limit'       => $limit,
            'total'       => intval($total),
            'total_pages' => $totalPages,
            'has_next'    => $page < $totalPages,
            'has_prev'    => $page > 1,
        ],
    ];
}

// ============================================================================
// Safe bind_param wrapper (handles intval() reference issue)
// ============================================================================

/**
 * Safely binds params to a prepared statement.
 * Automatically converts values to proper types based on the type string.
 * Avoids the PHP "cannot be passed by reference" error with intval().
 */
function safeBindParam($stmt, $types, array $params) {
    if (empty($params)) return;

    $refs = [];
    foreach ($params as $key => $value) {
        $typeChar = $types[$key] ?? 's';

        switch ($typeChar) {
            case 'i':
                $refs[$key] = intval($value);
                break;
            case 'd':
                $refs[$key] = floatval($value);
                break;
            default:
                $refs[$key] = strval($value);
                break;
        }
    }

    $stmt->bind_param($types, ...$refs);
}

/**
 * Safely execute a SELECT with pagination, returning paginated JSON response.
 */
function safePaginatedSelect($conn, $countSql, $dataSql, $params, $types, $page, $limit) {
    $offset = ($page - 1) * $limit;

    // Count total
    $stmt = $conn->prepare($countSql);
    if (!empty($params)) {
        safeBindParam($stmt, $types, $params);
    }
    $stmt->execute();
    $countResult = $stmt->get_result();
    $total = intval($countResult->fetch_assoc()['total']);
    $countResult->free();
    $stmt->close();

    // Fetch data
    $allParams = array_merge($params, [$limit, $offset]);
    $allTypes  = $types . 'ii';

    $stmt = $conn->prepare($dataSql);
    if (!empty($allParams)) {
        safeBindParam($stmt, $allTypes, $allParams);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    $records = [];
    while ($row = $result->fetch_assoc()) {
        $records[] = $row;
    }
    $result->free();
    $stmt->close();

    jsonResponse(buildPaginationResponse($total, $page, $limit, $records));
}
